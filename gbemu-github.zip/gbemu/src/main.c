/* main.c - Frontend Casio Graph 35+E II (fxSDK / gint)
 *
 * Écran cible : 128x64, 1 bit par pixel. On utilise le moteur de gris de gint
 * (dgray) pour obtenir 4 niveaux, ce qui colle exactement aux 4 teintes de la
 * Game Boy. Si dgray est désactivé, on retombe sur un seuillage 1 bit.
 *
 * Deux modes d'affichage :
 *   - SCALED : l'image 160x144 entière est réduite en 128x64 (perte de
 *     détail verticale importante, mais on voit tout).
 *   - CROP   : fenêtre 128x64 en pixels natifs, qui suit le sprite du joueur
 *     approximativement via SCX/SCY (image nette mais partielle).
 *
 * IMPORTANT : gb_t (~20-25 Ko avec VRAM+WRAM+framebuffer) est alloué sur le
 * tas (malloc), jamais en variable statique. La région RAM statique d'un
 * add-in fx-9860G est bien trop petite pour héberger ça en .bss ; le tas de
 * gint, lui, peut englober des bancs mémoire supplémentaires.
 */
#include <gint/display.h>
#include <gint/keyboard.h>
#include <gint/clock.h>
#include <gint/timer.h>
#include <gint/cpu.h>
#include <gint/gray.h>
#include <string.h>
#include <stdlib.h>

#include "gb.h"
#include "rom.h"   /* généré par tools/rom2c.py : gb_rom[] et gb_rom_size */

#define SCR_W 128
#define SCR_H 64

static gb_t *gb; /* alloué dans main() */

/* ---------- Tables de redimensionnement précalculées ---------- */
static uint8_t map_x[SCR_W];   /* colonne GB pour chaque colonne écran */
static uint8_t map_y[SCR_H];   /* ligne GB pour chaque ligne écran */

static void build_scale_tables(void)
{
    for (int x = 0; x < SCR_W; x++) map_x[x] = (uint8_t)((x * GB_W) / SCR_W);
    for (int y = 0; y < SCR_H; y++) map_y[y] = (uint8_t)((y * GB_H) / SCR_H);
}

/* Matrice de Bayer 4x4 pour le tramage quand on n'a pas les gris */
static const uint8_t bayer4[4][4] = {
    {  0,  8,  2, 10 },
    { 12,  4, 14,  6 },
    {  3, 11,  1,  9 },
    { 15,  7, 13,  5 }
};

typedef enum { VIEW_SCALED = 0, VIEW_CROP = 1 } view_mode_t;
static view_mode_t view_mode = VIEW_SCALED;
static int crop_x = 16, crop_y = 40; /* origine de la fenêtre en mode CROP */

/* ---------- Rendu : framebuffer GB -> VRAM gint ---------- */
static void render_gray(void)
{
    uint32_t *light, *dark;
    dgray_getvram(&light, &dark);

    for (int sy = 0; sy < SCR_H; sy++) {
        int gy = (view_mode == VIEW_SCALED) ? map_y[sy] : (crop_y + sy);
        if (gy >= GB_H) gy = GB_H - 1;

        uint32_t wl = 0, wd = 0;
        int word_index = sy * 4;
        int bit = 31;

        for (int sx = 0; sx < SCR_W; sx++) {
            int gx = (view_mode == VIEW_SCALED) ? map_x[sx] : (crop_x + sx);
            if (gx >= GB_W) gx = GB_W - 1;
            uint8_t shade = ppu_get_pixel(&gb->ppu, gx, gy); /* 0=blanc..3=noir */

            if (shade == 1 || shade == 3) wl |= (1u << bit);
            if (shade == 2 || shade == 3) wd |= (1u << bit);

            if (--bit < 0) {
                light[word_index] = wl;
                dark[word_index] = wd;
                word_index++;
                wl = wd = 0;
                bit = 31;
            }
        }
    }
}

static void render_mono(void)
{
    uint32_t *vram = gint_vram;
    for (int sy = 0; sy < SCR_H; sy++) {
        int gy = (view_mode == VIEW_SCALED) ? map_y[sy] : (crop_y + sy);
        if (gy >= GB_H) gy = GB_H - 1;

        uint32_t w = 0;
        int word_index = sy * 4;
        int bit = 31;

        for (int sx = 0; sx < SCR_W; sx++) {
            int gx = (view_mode == VIEW_SCALED) ? map_x[sx] : (crop_x + sx);
            if (gx >= GB_W) gx = GB_W - 1;
            int threshold = bayer4[sy & 3][sx & 3];
            int level = ppu_get_pixel(&gb->ppu, gx, gy) * 5; /* 0,5,10,15 */
            if (level > threshold) w |= (1u << bit);

            if (--bit < 0) {
                vram[word_index++] = w;
                w = 0;
                bit = 31;
            }
        }
    }
}

/* ---------- Clavier ---------- */
static void poll_input(void)
{
    uint8_t dpad = 0x0F, buttons = 0x0F;

    clearevents();

    if (keydown(KEY_RIGHT)) dpad &= ~0x01;
    if (keydown(KEY_LEFT))  dpad &= ~0x02;
    if (keydown(KEY_UP))    dpad &= ~0x04;
    if (keydown(KEY_DOWN))  dpad &= ~0x08;

    if (keydown(KEY_SHIFT)) buttons &= ~0x01; /* A */
    if (keydown(KEY_ALPHA)) buttons &= ~0x02; /* B */
    if (keydown(KEY_OPTN))  buttons &= ~0x04; /* SELECT */
    if (keydown(KEY_EXE))   buttons &= ~0x08; /* START */

    if ((dpad != gb->mmu.joypad_dpad) || (buttons != gb->mmu.joypad_buttons))
        gb_request_interrupt(gb, INT_JOYPAD);

    gb->mmu.joypad_dpad = dpad;
    gb->mmu.joypad_buttons = buttons;
}

static bool toggle_pressed = false;

static bool handle_system_keys(void)
{
    if (keydown(KEY_EXIT)) return false; /* quitter */

    if (keydown(KEY_F1)) {
        if (!toggle_pressed) {
            view_mode = (view_mode == VIEW_SCALED) ? VIEW_CROP : VIEW_SCALED;
            toggle_pressed = true;
        }
    } else {
        toggle_pressed = false;
    }

    if (view_mode == VIEW_CROP) {
        if (keydown(KEY_F2) && crop_x > 0) crop_x -= 2;
        if (keydown(KEY_F3) && crop_x < GB_W - SCR_W) crop_x += 2;
        if (keydown(KEY_F5) && crop_y > 0) crop_y -= 2;
        if (keydown(KEY_F6) && crop_y < GB_H - SCR_H) crop_y += 2;
    }
    return true;
}

static void fatal_error(const char *msg)
{
    dclear(C_WHITE);
    dtext(2, 2, C_BLACK, "GBEmu - erreur");
    dtext(2, 14, C_BLACK, msg);
    dtext(2, 30, C_BLACK, "EXIT pour quitter");
    dupdate();
    while (!keydown(KEY_EXIT)) { clearevents(); }
}

/* ---- Options de compilation (voir README) ----
 *   -DGBEMU_FRAMESKIP=N : n'affiche qu'une image sur N+1 (defaut 1)
 *   -DGBEMU_NO_GRAY     : desactive les 4 niveaux de gris (tramage 1 bit)
 *   -DGBEMU_BENCHMARK   : lance un benchmark chronometre a la main, au lieu
 *                         du jeu (300 images = 5 s de temps Game Boy)
 */
#ifndef GBEMU_FRAMESKIP
#define GBEMU_FRAMESKIP 1
#endif

#ifdef GBEMU_BENCHMARK
static void run_benchmark(void)
{
    dclear(C_WHITE);
    dtext(2, 2, C_BLACK, "Benchmark : EXE pour");
    dtext(2, 12, C_BLACK, "demarrer, chrono pret");
    dupdate();
    while (!keydown(KEY_EXE)) { clearevents(); }
    clearevents();

    dclear(C_WHITE);
    dtext(2, 2, C_BLACK, "GO !");
    dupdate();

    /* Rendu complet a chaque image : c'est le pire cas, volontairement. */
    for (int i = 0; i < 300; i++) {
        gb_run_frame(gb);
        if (dgray_enabled()) render_gray(); else render_mono();
        dupdate();
    }

    dclear(C_WHITE);
    dtext(2, 2, C_BLACK, "FINI");
    dtext(2, 20, C_BLACK, "300 images = 5 s emulees");
    dtext(2, 40, C_BLACK, "EXIT pour quitter");
    dupdate();
    while (!keydown(KEY_EXIT)) { clearevents(); }
}
#endif

int main(void)
{
    build_scale_tables();

    clock_set_speed(CLOCK_SPEED_F3);

    /* gb_t est gros (VRAM+WRAM+framebuffer compresse) : sur le tas, jamais
       en variable statique (voir commentaire en tete de fichier). */
    gb = (gb_t *)malloc(sizeof(gb_t));
    if (!gb) {
        fatal_error("malloc(gb_t) a echoue");
        return 1;
    }

#ifndef GBEMU_NO_GRAY
    dgray(DGRAY_ON);
#endif
    gb_init(gb, gb_rom, gb_rom_size);

#ifdef GBEMU_BENCHMARK
    run_benchmark();
#else
    bool running = true;
    int frame_counter = 0;

    while (running) {
        poll_input();
        running = handle_system_keys();

        gb_run_frame(gb);

        if ((frame_counter++ % (GBEMU_FRAMESKIP + 1)) == 0) {
            if (dgray_enabled())
                render_gray();
            else
                render_mono();
            dupdate();
        }
    }
#endif

#ifndef GBEMU_NO_GRAY
    dgray(DGRAY_OFF);
#endif
    clock_set_speed(CLOCK_SPEED_DEFAULT);

    if (gb->mmu.cart.ram) free(gb->mmu.cart.ram);
    free(gb);
    return 0;
}
