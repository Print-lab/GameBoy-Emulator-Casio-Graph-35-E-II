/* ppu.c - Rendu vidéo Game Boy (mode 2/3/0/1), scanline-based.
 * Produit un framebuffer 160x144 en nuances 0-3 (0=blanc,3=noir).
 * La conversion vers l'écran 128x64 1-bit de la calculatrice se fait
 * côté main.c (redimensionnement + dithering).
 */
#include <string.h>
#include "gb.h"

#define MODE_HBLANK 0
#define MODE_VBLANK 1
#define MODE_OAM    2
#define MODE_XFER   3

void ppu_init(ppu_t *ppu)
{
    memset(ppu, 0, sizeof(*ppu));
    ppu->mode = MODE_OAM;
}

static uint8_t shade_from_palette(uint8_t pal, uint8_t color_id)
{
    return (pal >> (color_id * 2)) & 0x03;
}

static inline uint8_t vram_byte(const mmu_t *m, uint16_t addr) {
    return m->vram[addr - 0x8000];
}

static void draw_scanline(gb_t *gb, int ly)
{
    mmu_t *m = &gb->mmu;
    uint8_t lcdc = m->io[IO_LCDC];
    if (!(lcdc & 0x80)) return; /* LCD off */

    uint8_t bgp = m->io[IO_BGP];
    uint8_t scx = m->io[IO_SCX];
    uint8_t scy = m->io[IO_SCY];
    uint8_t wy  = m->io[IO_WY];
    uint8_t wx  = (uint8_t)(m->io[IO_WX] - 7);
    bool win_enable = (lcdc & 0x20) && (wy <= ly);

    uint8_t bg_line_ids[GB_W]; /* color id (0-3) avant palette, pour priorité sprites */

    /* On ne relit les 3 octets d'une tuile (id + 2 plans de bits) que quand
       on change de tuile (tous les 8 pixels), au lieu de le faire a chaque
       pixel. Sur 160 pixels ca passe de ~480 lectures VRAM/ligne a ~60 :
       c'est le principal cout du rendu, et donc le principal gain possible. */
    int last_key = -1;
    uint8_t lo = 0, hi = 0;

    for (int x = 0; x < GB_W; x++) {
        uint8_t color_id = 0;
        if (lcdc & 0x01) { /* BG/Window enable (toujours vrai sur DMG sauf CGB) */
            bool use_window = win_enable && (x >= wx);
            uint16_t tile_map_base;
            int px, py;
            if (use_window) {
                tile_map_base = (lcdc & 0x40) ? 0x9C00 : 0x9800;
                px = x - wx;
                py = ly - wy;
            } else {
                tile_map_base = (lcdc & 0x08) ? 0x9C00 : 0x9800;
                px = (x + scx) & 0xFF;
                py = (ly + scy) & 0xFF;
            }
            int tile_col = px >> 3, tile_row = py >> 3;
            int key = (use_window ? 0x10000 : 0) | (tile_row << 8) | tile_col
                    | (tile_map_base == 0x9C00 ? 0x20000 : 0);

            if (key != last_key) {
                uint16_t map_addr = tile_map_base + tile_row * 32 + tile_col;
                uint8_t tile_id = vram_byte(m, map_addr);

                uint16_t tile_addr;
                if (lcdc & 0x10) {
                    tile_addr = 0x8000 + (uint16_t)tile_id * 16;
                } else {
                    tile_addr = 0x9000 + (int16_t)(int8_t)tile_id * 16;
                }
                int line_in_tile = py & 7;
                lo = vram_byte(m, tile_addr + line_in_tile * 2);
                hi = vram_byte(m, tile_addr + line_in_tile * 2 + 1);
                last_key = key;
            }
            int bit = 7 - (px & 7);
            color_id = ((hi >> bit) & 1) << 1 | ((lo >> bit) & 1);
        }
        bg_line_ids[x] = color_id;
        ppu_set_pixel(&gb->ppu, x, ly, shade_from_palette(bgp, color_id));
    }

    if (lcdc & 0x02) { /* sprites (OBJ) */
        int sprite_h = (lcdc & 0x04) ? 16 : 8;
        int drawn = 0;
        for (int i = 0; i < 40 && drawn < 10; i++) {
            uint8_t sy = m->oam[i * 4 + 0];
            uint8_t sx = m->oam[i * 4 + 1];
            uint8_t tile = m->oam[i * 4 + 2];
            uint8_t attr = m->oam[i * 4 + 3];
            int y = sy - 16, xx = sx - 8;
            if (ly < y || ly >= y + sprite_h) continue;
            drawn++;
            int line = ly - y;
            if (attr & 0x40) line = sprite_h - 1 - line; /* flip Y */
            if (sprite_h == 16) tile &= 0xFE;
            uint16_t tile_addr = 0x8000 + (uint16_t)tile * 16 + line * 2;
            uint8_t lo = vram_byte(m, tile_addr);
            uint8_t hi = vram_byte(m, tile_addr + 1);
            uint8_t pal = (attr & 0x10) ? m->io[IO_OBP1] : m->io[IO_OBP0];
            for (int bx = 0; bx < 8; bx++) {
                int bit = (attr & 0x20) ? bx : 7 - bx; /* flip X */
                uint8_t cid = ((hi >> bit) & 1) << 1 | ((lo >> bit) & 1);
                if (cid == 0) continue; /* transparent */
                int px = xx + bx;
                if (px < 0 || px >= GB_W) continue;
                if ((attr & 0x80) && bg_line_ids[px] != 0) continue; /* priorité BG */
                ppu_set_pixel(&gb->ppu, px, ly, shade_from_palette(pal, cid));
            }
        }
    }
}

void ppu_step(gb_t *gb, int cycles)
{
    ppu_t *p = &gb->ppu;
    mmu_t *m = &gb->mmu;
    uint8_t lcdc = m->io[IO_LCDC];
    if (!(lcdc & 0x80)) {
        p->mode_clock = 0; p->line = 0; m->io[IO_LY] = 0;
        p->mode = MODE_HBLANK;
        /* Quirk materiel reel : quand le LCD est eteint, les bits de mode de
           STAT (0-1) lisent 0 en permanence, peu importe le mode dans lequel
           on etait juste avant de l'eteindre. Sans ca, un jeu qui attend en
           boucle "STAT indique le mode 0" avant de continuer son
           initialisation reste bloque pour toujours des qu'il eteint le LCD
           avec du mode 1/2/3 fige dans le registre. */
        m->io[IO_STAT] &= ~0x03;
        return;
    }

    p->mode_clock += cycles;

    switch (p->mode) {
    case MODE_OAM:
        if (p->mode_clock >= 80) {
            p->mode_clock -= 80;
            p->mode = MODE_XFER;
        }
        break;
    case MODE_XFER:
        if (p->mode_clock >= 172) {
            p->mode_clock -= 172;
            p->mode = MODE_HBLANK;
            draw_scanline(gb, p->line);
            if (m->io[IO_STAT] & 0x08) gb_request_interrupt(gb, INT_LCDSTAT);
        }
        break;
    case MODE_HBLANK:
        if (p->mode_clock >= 204) {
            p->mode_clock -= 204;
            p->line++;
            m->io[IO_LY] = p->line;
            if (p->line == 144) {
                p->mode = MODE_VBLANK;
                p->frame_ready = true;
                gb_request_interrupt(gb, INT_VBLANK);
                if (m->io[IO_STAT] & 0x10) gb_request_interrupt(gb, INT_LCDSTAT);
            } else {
                p->mode = MODE_OAM;
                if (m->io[IO_STAT] & 0x20) gb_request_interrupt(gb, INT_LCDSTAT);
            }
        }
        break;
    case MODE_VBLANK:
        if (p->mode_clock >= 456) {
            p->mode_clock -= 456;
            p->line++;
            if (p->line > 153) {
                p->line = 0;
                m->io[IO_LY] = 0;
                p->mode = MODE_OAM;
                if (m->io[IO_STAT] & 0x20) gb_request_interrupt(gb, INT_LCDSTAT);
            } else {
                m->io[IO_LY] = p->line;
            }
        }
        break;
    }

    uint8_t stat = m->io[IO_STAT] & 0xF8;
    stat |= (uint8_t)p->mode;
    if (m->io[IO_LY] == m->io[IO_LYC]) {
        stat |= 0x04;
        if (m->io[IO_STAT] & 0x40) gb_request_interrupt(gb, INT_LCDSTAT);
    }
    m->io[IO_STAT] = stat;
}
