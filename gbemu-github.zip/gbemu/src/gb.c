/* gb.c - Assemblage de la machine et boucle d'exécution par frame */
#include <string.h>
#include <stdlib.h>
#include "gb.h"

/* Une frame Game Boy = 154 lignes * 456 cycles = 70224 cycles T */
#define CYCLES_PER_FRAME 70224

void gb_init(gb_t *gb, const uint8_t *rom, uint32_t rom_size)
{
    memset(gb, 0, sizeof(*gb));
    cpu_init(&gb->cpu);
    mmu_init(&gb->mmu, rom, rom_size);
    ppu_init(&gb->ppu);
    timer_init(&gb->timer);

    /* RAM cartouche : allouée si la ROM en déclare. On plafonne à 32 Ko pour
       ne pas exploser la mémoire de la calculatrice. */
    if (gb->mmu.cart.ram_size > 0) {
        if (gb->mmu.cart.ram_size > 32u * 1024u) gb->mmu.cart.ram_size = 32u * 1024u;
        gb->mmu.cart.ram = (uint8_t *)malloc(gb->mmu.cart.ram_size);
        if (gb->mmu.cart.ram)
            memset(gb->mmu.cart.ram, 0, gb->mmu.cart.ram_size);
        else
            gb->mmu.cart.ram_size = 0;
    }

    /* Valeurs des registres IO après le boot ROM DMG */
    uint8_t *io = gb->mmu.io;
    io[IO_JOYP] = 0xCF; io[IO_DIV] = 0xAB; io[IO_TIMA] = 0x00;
    io[IO_TMA] = 0x00;  io[IO_TAC] = 0xF8; io[IO_IF] = 0xE1;
    io[IO_LCDC] = 0x91; io[IO_STAT] = 0x85;
    io[IO_SCY] = 0x00;  io[IO_SCX] = 0x00; io[IO_LY] = 0x00; io[IO_LYC] = 0x00;
    io[IO_BGP] = 0xFC;  io[IO_OBP0] = 0xFF; io[IO_OBP1] = 0xFF;
    io[IO_WY] = 0x00;   io[IO_WX] = 0x00;
    gb->mmu.ie_reg = 0x00;
}

void gb_run_frame(gb_t *gb)
{
    int budget = CYCLES_PER_FRAME;
    gb->ppu.frame_ready = false;

    while (budget > 0) {
        int cycles = cpu_step(gb);
        timer_step(gb, cycles);
        ppu_step(gb, cycles);
        budget -= cycles;
        /* On s'arrête dès que le PPU a fini une image, pour rester synchro
           même si le compte de cycles dérive légèrement. */
        if (gb->ppu.frame_ready) break;
    }
}
