/* timer.c - DIV / TIMA / TMA / TAC */
#include "gb.h"

void timer_init(gbtimer_t *t)
{
    t->div_counter = 0;
    t->tima_counter = 0;
}

static const int tac_freq[4] = {1024, 16, 64, 256}; /* cycles CPU par tick TIMA */

void timer_step(gb_t *gb, int cycles)
{
    mmu_t *m = &gb->mmu;
    gbtimer_t *t = &gb->timer;

    t->div_counter += cycles;
    while (t->div_counter >= 256) {
        t->div_counter -= 256;
        m->io[IO_DIV]++;
    }

    uint8_t tac = m->io[IO_TAC];
    if (!(tac & 0x04)) return; /* timer désactivé */

    int freq = tac_freq[tac & 0x03];
    t->tima_counter += cycles;
    while (t->tima_counter >= freq) {
        t->tima_counter -= freq;
        uint8_t tima = m->io[IO_TIMA];
        if (tima == 0xFF) {
            m->io[IO_TIMA] = m->io[IO_TMA];
            gb_request_interrupt(gb, INT_TIMER);
        } else {
            m->io[IO_TIMA] = tima + 1;
        }
    }
}
