/* cpu.c - Cœur CPU SM83 (Game Boy), décodage par champs x/y/z/p/q.
 *
 * Référence de la méthode de décodage : structure d'opcode Z80 documentée
 * publiquement (blocs x=opcode>>6, y=(opcode>>3)&7, z=opcode&7, p=y>>1, q=y&1),
 * adaptée aux différences GB (pas d'IX/IY, LDH/LD(HL+-)/RETI à la place de
 * certains opcodes Z80, pas de flags P/V ni S).
 *
 * IMPORTANT : tous les acces aux registres 8 bits passent par les fonctions
 * r_a/r_b/.../set_a/set_b/... definies dans gb.h, jamais par un champ direct
 * du type c->a. Ces fonctions extraient l'octet haut/bas d'une paire 16 bits
 * par arithmetique, ce qui fonctionne identiquement sur le PC de
 * developpement (little-endian) et sur le SH-4 de la calculatrice
 * (big-endian) -- une union aurait donne un resultat different selon la
 * machine et casse silencieusement l'emulation sur la cible reelle.
 */
#include "gb.h"

static inline uint8_t fetch8(gb_t *gb)  { return mmu_read(gb, gb->cpu.pc++); }
static inline uint16_t fetch16(gb_t *gb) {
    uint8_t lo = fetch8(gb);
    uint8_t hi = fetch8(gb);
    return (uint16_t)(hi << 8) | lo;
}

static inline void set_flag(cpu_t *c, uint8_t mask, bool v) {
    if (v) set_f(c, (uint8_t)(r_f(c) | mask));
    else   set_f(c, (uint8_t)(r_f(c) & ~mask));
}
static inline bool get_flag(cpu_t *c, uint8_t mask) { return (r_f(c) & mask) != 0; }

void cpu_init(cpu_t *cpu)
{
    /* État après le boot ROM officiel (DMG), pour permettre de sauter le
       boot ROM (que nous n'émulons pas ici). */
    cpu->af = 0x01B0;
    cpu->bc = 0x0013;
    cpu->de = 0x00D8;
    cpu->hl = 0x014D;
    cpu->sp = 0xFFFE;
    cpu->pc = 0x0100;
    cpu->ime = false;
    cpu->ime_pending = false;
    cpu->halted = false;
    cpu->stopped = false;
    cpu->cycles = 0;
}

/* ---- Accès registres 8 bits via index 0-7 : B,C,D,E,H,L,(HL),A ---- */
static uint8_t get_r8(gb_t *gb, int idx)
{
    cpu_t *c = &gb->cpu;
    switch (idx) {
        case 0: return r_b(c); case 1: return r_c(c);
        case 2: return r_d(c); case 3: return r_e(c);
        case 4: return r_h(c); case 5: return r_l(c);
        case 6: return mmu_read(gb, c->hl);
        case 7: return r_a(c);
    }
    return 0xFF;
}
static void set_r8(gb_t *gb, int idx, uint8_t v)
{
    cpu_t *c = &gb->cpu;
    switch (idx) {
        case 0: set_b(c, v); return; case 1: set_c(c, v); return;
        case 2: set_d(c, v); return; case 3: set_e(c, v); return;
        case 4: set_h(c, v); return; case 5: set_l(c, v); return;
        case 6: mmu_write(gb, c->hl, v); return;
        case 7: set_a(c, v); return;
    }
}

/* ---- Paires 16 bits : BC,DE,HL,SP (rp) ---- */
static uint16_t get_rp(cpu_t *c, int p) {
    switch (p) { case 0: return c->bc; case 1: return c->de;
                 case 2: return c->hl; case 3: return c->sp; }
    return 0;
}
static void set_rp(cpu_t *c, int p, uint16_t v) {
    switch (p) { case 0: c->bc = v; return; case 1: c->de = v; return;
                 case 2: c->hl = v; return; case 3: c->sp = v; return; }
}
/* ---- Paires 16 bits pour PUSH/POP : BC,DE,HL,AF (rp2) ---- */
static uint16_t get_rp2(cpu_t *c, int p) {
    switch (p) { case 0: return c->bc; case 1: return c->de;
                 case 2: return c->hl; case 3: return c->af & 0xFFF0; }
    return 0;
}
static void set_rp2(cpu_t *c, int p, uint16_t v) {
    switch (p) { case 0: c->bc = v; return; case 1: c->de = v; return;
                 case 2: c->hl = v; return; case 3: c->af = v & 0xFFF0; return; }
}

static bool test_cc(cpu_t *c, int y) {
    switch (y) {
        case 0: return !get_flag(c, FLAG_Z);
        case 1: return  get_flag(c, FLAG_Z);
        case 2: return !get_flag(c, FLAG_C);
        case 3: return  get_flag(c, FLAG_C);
    }
    return false;
}

/* ---- ALU 8 bits : ADD,ADC,SUB,SBC,AND,XOR,OR,CP sur A ---- */
static void alu_op(cpu_t *c, int op, uint8_t val)
{
    uint8_t a = r_a(c);
    int carry_in = get_flag(c, FLAG_C) ? 1 : 0;
    int result;
    uint8_t r;
    switch (op) {
    case 0: /* ADD */
        result = a + val;
        set_flag(c, FLAG_H, ((a & 0xF) + (val & 0xF)) > 0xF);
        set_flag(c, FLAG_C, result > 0xFF);
        set_flag(c, FLAG_N, false);
        r = (uint8_t)result; set_a(c, r);
        set_flag(c, FLAG_Z, r == 0);
        break;
    case 1: /* ADC */
        result = a + val + carry_in;
        set_flag(c, FLAG_H, ((a & 0xF) + (val & 0xF) + carry_in) > 0xF);
        set_flag(c, FLAG_C, result > 0xFF);
        set_flag(c, FLAG_N, false);
        r = (uint8_t)result; set_a(c, r);
        set_flag(c, FLAG_Z, r == 0);
        break;
    case 2: /* SUB */
        result = a - val;
        set_flag(c, FLAG_H, (a & 0xF) < (val & 0xF));
        set_flag(c, FLAG_C, a < val);
        set_flag(c, FLAG_N, true);
        r = (uint8_t)result; set_a(c, r);
        set_flag(c, FLAG_Z, r == 0);
        break;
    case 3: /* SBC */
        result = a - val - carry_in;
        set_flag(c, FLAG_H, (int)(a & 0xF) - (val & 0xF) - carry_in < 0);
        set_flag(c, FLAG_C, (int)a - val - carry_in < 0);
        set_flag(c, FLAG_N, true);
        r = (uint8_t)result; set_a(c, r);
        set_flag(c, FLAG_Z, r == 0);
        break;
    case 4: /* AND */
        r = (uint8_t)(a & val); set_a(c, r);
        set_flag(c, FLAG_Z, r == 0); set_flag(c, FLAG_N, false);
        set_flag(c, FLAG_H, true); set_flag(c, FLAG_C, false);
        break;
    case 5: /* XOR */
        r = (uint8_t)(a ^ val); set_a(c, r);
        set_flag(c, FLAG_Z, r == 0); set_flag(c, FLAG_N, false);
        set_flag(c, FLAG_H, false); set_flag(c, FLAG_C, false);
        break;
    case 6: /* OR */
        r = (uint8_t)(a | val); set_a(c, r);
        set_flag(c, FLAG_Z, r == 0); set_flag(c, FLAG_N, false);
        set_flag(c, FLAG_H, false); set_flag(c, FLAG_C, false);
        break;
    case 7: /* CP */
        set_flag(c, FLAG_Z, a == val);
        set_flag(c, FLAG_N, true);
        set_flag(c, FLAG_H, (a & 0xF) < (val & 0xF));
        set_flag(c, FLAG_C, a < val);
        break;
    }
}

static uint8_t inc8(cpu_t *c, uint8_t v) {
    uint8_t r = v + 1;
    set_flag(c, FLAG_H, (v & 0xF) == 0xF);
    set_flag(c, FLAG_N, false);
    set_flag(c, FLAG_Z, r == 0);
    return r;
}
static uint8_t dec8(cpu_t *c, uint8_t v) {
    uint8_t r = v - 1;
    set_flag(c, FLAG_H, (v & 0xF) == 0x0);
    set_flag(c, FLAG_N, true);
    set_flag(c, FLAG_Z, r == 0);
    return r;
}

/* ---- Rotations/décalages 8 bits (utilisées par RLCA... et le préfixe CB) ---- */
static uint8_t rot_op(cpu_t *c, int op, uint8_t v, bool is_cb)
{
    bool carry = get_flag(c, FLAG_C);
    uint8_t r = v;
    bool new_c = false;
    switch (op) {
    case 0: /* RLC */ new_c = v & 0x80; r = (uint8_t)((v << 1) | (new_c ? 1 : 0)); break;
    case 1: /* RRC */ new_c = v & 0x01; r = (uint8_t)((v >> 1) | (new_c ? 0x80 : 0)); break;
    case 2: /* RL  */ new_c = v & 0x80; r = (uint8_t)((v << 1) | (carry ? 1 : 0)); break;
    case 3: /* RR  */ new_c = v & 0x01; r = (uint8_t)((v >> 1) | (carry ? 0x80 : 0)); break;
    case 4: /* SLA */ new_c = v & 0x80; r = (uint8_t)(v << 1); break;
    case 5: /* SRA */ new_c = v & 0x01; r = (uint8_t)((v >> 1) | (v & 0x80)); break;
    case 6: /* SWAP*/ r = (uint8_t)((v << 4) | (v >> 4)); break;
    case 7: /* SRL */ new_c = v & 0x01; r = (uint8_t)(v >> 1); break;
    }
    set_flag(c, FLAG_C, new_c);
    set_flag(c, FLAG_N, false);
    set_flag(c, FLAG_H, false);
    /* RLCA/RRCA/RLA/RRA (non-CB) mettent toujours Z=0 ; les versions CB
       calculent Z normalement. */
    set_flag(c, FLAG_Z, is_cb ? (r == 0) : false);
    return r;
}

static void push16(gb_t *gb, uint16_t v) {
    gb->cpu.sp -= 2;
    mmu_write(gb, gb->cpu.sp, v & 0xFF);
    mmu_write(gb, gb->cpu.sp + 1, v >> 8);
}
static uint16_t pop16(gb_t *gb) {
    uint8_t lo = mmu_read(gb, gb->cpu.sp);
    uint8_t hi = mmu_read(gb, gb->cpu.sp + 1);
    gb->cpu.sp += 2;
    return (uint16_t)(hi << 8) | lo;
}

static int exec_cb(gb_t *gb)
{
    cpu_t *c = &gb->cpu;
    uint8_t op = fetch8(gb);
    int x = op >> 6, y = (op >> 3) & 7, z = op & 7;
    uint8_t v = get_r8(gb, z);
    int cycles = (z == 6) ? 16 : 8;

    switch (x) {
    case 0: /* rotations/décalages */
        v = rot_op(c, y, v, true);
        set_r8(gb, z, v);
        break;
    case 1: /* BIT y,r */
        set_flag(c, FLAG_Z, !(v & (1 << y)));
        set_flag(c, FLAG_N, false);
        set_flag(c, FLAG_H, true);
        cycles = (z == 6) ? 12 : 8;
        break;
    case 2: /* RES y,r */
        set_r8(gb, z, v & ~(1 << y));
        break;
    case 3: /* SET y,r */
        set_r8(gb, z, v | (1 << y));
        break;
    }
    return cycles;
}

static void handle_interrupts(gb_t *gb)
{
    cpu_t *c = &gb->cpu;
    mmu_t *m = &gb->mmu;
    uint8_t pending = m->io[IO_IF] & m->ie_reg & 0x1F;
    if (!pending) return;

    if (c->halted) c->halted = false; /* un HALT se termine même si IME=0 */
    if (!c->ime) return;

    for (int bit = 0; bit < 5; bit++) {
        if (pending & (1 << bit)) {
            c->ime = false;
            m->io[IO_IF] &= ~(1 << bit);
            push16(gb, c->pc);
            c->pc = 0x0040 + bit * 8;
            c->cycles += 20;
            return;
        }
    }
}

int cpu_step(gb_t *gb)
{
    cpu_t *c = &gb->cpu;

    if (c->ime_pending) { c->ime_pending = false; c->ime = true; }

    handle_interrupts(gb);

    if (c->halted) return 4; /* consomme un cycle "fictif" en attendant une IRQ */

    uint8_t op = fetch8(gb);
    int x = op >> 6, y = (op >> 3) & 7, z = op & 7, p = y >> 1, q = y & 1;
    int cycles = 4;

    switch (x) {
    case 0:
        switch (z) {
        case 0:
            if (y == 0) { /* NOP */ }
            else if (y == 1) { uint16_t nn = fetch16(gb); mmu_write(gb, nn, c->sp & 0xFF);
                                mmu_write(gb, nn + 1, c->sp >> 8); cycles = 20; }
            else if (y == 2) { c->stopped = true; fetch8(gb); /* STOP a un octet suivant (0x00) */ }
            else if (y == 3) { int8_t d = (int8_t)fetch8(gb); c->pc += d; cycles = 12; }
            else { int8_t d = (int8_t)fetch8(gb);
                   if (test_cc(c, y - 4)) { c->pc += d; cycles = 12; } else cycles = 8; }
            break;
        case 1:
            if (q == 0) { set_rp(c, p, fetch16(gb)); cycles = 12; }
            else {
                uint16_t hl = c->hl, rp = get_rp(c, p);
                int r = hl + rp;
                set_flag(c, FLAG_N, false);
                set_flag(c, FLAG_H, ((hl & 0xFFF) + (rp & 0xFFF)) > 0xFFF);
                set_flag(c, FLAG_C, r > 0xFFFF);
                c->hl = (uint16_t)r;
                cycles = 8;
            }
            break;
        case 2:
            if (q == 0) {
                uint16_t addr = (p == 0) ? c->bc : (p == 1) ? c->de : c->hl;
                mmu_write(gb, addr, r_a(c));
                if (p == 2) c->hl++; else if (p == 3) c->hl--;
            } else {
                uint16_t addr = (p == 0) ? c->bc : (p == 1) ? c->de : c->hl;
                set_a(c, mmu_read(gb, addr));
                if (p == 2) c->hl++; else if (p == 3) c->hl--;
            }
            cycles = 8;
            break;
        case 3:
            set_rp(c, p, get_rp(c, p) + (q == 0 ? 1 : -1));
            cycles = 8;
            break;
        case 4:
            set_r8(gb, y, inc8(c, get_r8(gb, y)));
            cycles = (y == 6) ? 12 : 4;
            break;
        case 5:
            set_r8(gb, y, dec8(c, get_r8(gb, y)));
            cycles = (y == 6) ? 12 : 4;
            break;
        case 6:
            set_r8(gb, y, fetch8(gb));
            cycles = (y == 6) ? 12 : 8;
            break;
        case 7:
            switch (y) {
            case 0: set_a(c, rot_op(c, 0, r_a(c), false)); break; /* RLCA */
            case 1: set_a(c, rot_op(c, 1, r_a(c), false)); break; /* RRCA */
            case 2: set_a(c, rot_op(c, 2, r_a(c), false)); break; /* RLA  */
            case 3: set_a(c, rot_op(c, 3, r_a(c), false)); break; /* RRA  */
            case 4: { /* DAA */
                int a = r_a(c);
                if (!get_flag(c, FLAG_N)) {
                    if (get_flag(c, FLAG_H) || (a & 0xF) > 9) a += 0x06;
                    if (get_flag(c, FLAG_C) || a > 0x9F) { a += 0x60; set_flag(c, FLAG_C, true); }
                } else {
                    if (get_flag(c, FLAG_H)) a = (a - 6) & 0xFF;
                    if (get_flag(c, FLAG_C)) a -= 0x60;
                }
                set_a(c, (uint8_t)a);
                set_flag(c, FLAG_H, false);
                set_flag(c, FLAG_Z, (uint8_t)a == 0);
                break;
            }
            case 5: set_a(c, (uint8_t)~r_a(c)); set_flag(c, FLAG_N, true); set_flag(c, FLAG_H, true); break; /* CPL */
            case 6: set_flag(c, FLAG_N, false); set_flag(c, FLAG_H, false); set_flag(c, FLAG_C, true); break; /* SCF */
            case 7: set_flag(c, FLAG_N, false); set_flag(c, FLAG_H, false);
                    set_flag(c, FLAG_C, !get_flag(c, FLAG_C)); break; /* CCF */
            }
            break;
        }
        break;

    case 1:
        if (y == 6 && z == 6) { c->halted = true; }
        else { set_r8(gb, y, get_r8(gb, z)); cycles = (y == 6 || z == 6) ? 8 : 4; }
        break;

    case 2:
        alu_op(c, y, get_r8(gb, z));
        cycles = (z == 6) ? 8 : 4;
        break;

    case 3:
        switch (z) {
        case 0:
            if (y <= 3) { if (test_cc(c, y)) { c->pc = pop16(gb); cycles = 20; } else cycles = 8; }
            else if (y == 4) { uint8_t n = fetch8(gb); mmu_write(gb, 0xFF00 + n, r_a(c)); cycles = 12; }
            else if (y == 5) { int8_t d = (int8_t)fetch8(gb); int r = c->sp + d;
                                set_flag(c, FLAG_Z, false); set_flag(c, FLAG_N, false);
                                set_flag(c, FLAG_H, ((c->sp ^ d ^ r) & 0x10) != 0);
                                set_flag(c, FLAG_C, ((c->sp ^ d ^ r) & 0x100) != 0);
                                c->sp = (uint16_t)r; cycles = 16; }
            else if (y == 6) { uint8_t n = fetch8(gb); set_a(c, mmu_read(gb, 0xFF00 + n)); cycles = 12; }
            else { int8_t d = (int8_t)fetch8(gb); int r = c->sp + d;
                   set_flag(c, FLAG_Z, false); set_flag(c, FLAG_N, false);
                   set_flag(c, FLAG_H, ((c->sp ^ d ^ r) & 0x10) != 0);
                   set_flag(c, FLAG_C, ((c->sp ^ d ^ r) & 0x100) != 0);
                   c->hl = (uint16_t)r; cycles = 12; }
            break;
        case 1:
            if (q == 0) { set_rp2(c, p, pop16(gb)); cycles = 12; }
            else {
                if (p == 0) { c->pc = pop16(gb); cycles = 16; }
                else if (p == 1) { c->pc = pop16(gb); c->ime = true; cycles = 16; } /* RETI */
                else if (p == 2) { c->pc = c->hl; cycles = 4; } /* JP (HL) */
                else { c->sp = c->hl; cycles = 8; } /* LD SP,HL */
            }
            break;
        case 2:
            if (y <= 3) { uint16_t nn = fetch16(gb);
                          if (test_cc(c, y)) { c->pc = nn; cycles = 16; } else cycles = 12; }
            else if (y == 4) { mmu_write(gb, 0xFF00 + r_c(c), r_a(c)); cycles = 8; }
            else if (y == 5) { uint16_t nn = fetch16(gb); mmu_write(gb, nn, r_a(c)); cycles = 16; }
            else if (y == 6) { set_a(c, mmu_read(gb, 0xFF00 + r_c(c))); cycles = 8; }
            else { uint16_t nn = fetch16(gb); set_a(c, mmu_read(gb, nn)); cycles = 16; }
            break;
        case 3:
            if (y == 0) { c->pc = fetch16(gb); cycles = 16; }
            else if (y == 1) { cycles = exec_cb(gb); }
            else if (y == 6) { c->ime = false; c->ime_pending = false; }
            else if (y == 7) { c->ime_pending = true; }
            /* y=2,3,4,5 : opcodes invalides sur GB (OUT/IN/EX Z80) -> no-op */
            break;
        case 4:
            if (y <= 3) { uint16_t nn = fetch16(gb);
                          if (test_cc(c, y)) { push16(gb, c->pc); c->pc = nn; cycles = 24; }
                          else cycles = 12; }
            /* y=4..7 : invalides sur GB */
            break;
        case 5:
            if (q == 0) { push16(gb, get_rp2(c, p)); cycles = 16; }
            else if (p == 0) { uint16_t nn = fetch16(gb); push16(gb, c->pc); c->pc = nn; cycles = 24; }
            /* p=1,2,3 (0xDD,0xED,0xFD) : invalides sur GB */
            break;
        case 6:
            alu_op(c, y, fetch8(gb));
            cycles = 8;
            break;
        case 7:
            push16(gb, c->pc);
            c->pc = y * 8;
            cycles = 16;
            break;
        }
        break;
    }

    c->cycles += cycles;
    return cycles;
}
