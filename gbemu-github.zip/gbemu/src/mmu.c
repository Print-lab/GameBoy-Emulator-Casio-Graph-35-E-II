/* mmu.c - Bus mémoire Game Boy + gestion MBC simplifiée (0, 1, 3) */
#include <string.h>
#include "gb.h"

static mbc_type_t detect_mbc(const uint8_t *rom)
{
    uint8_t code = rom[0x147];
    switch (code) {
        case 0x00: return MBC_NONE;
        case 0x01: case 0x02: case 0x03: return MBC_1;
        case 0x05: case 0x06: return MBC_2;
        case 0x0F: case 0x10: case 0x11: case 0x12: case 0x13: return MBC_3;
        case 0x19: case 0x1A: case 0x1B: case 0x1C: case 0x1D: case 0x1E: return MBC_5;
        default: return MBC_UNSUPPORTED;
    }
}

void mmu_init(mmu_t *mmu, const uint8_t *rom, uint32_t rom_size)
{
    memset(mmu, 0, sizeof(*mmu));
    mmu->cart.rom = rom;
    mmu->cart.rom_size = rom_size;
    mmu->cart.mbc = detect_mbc(rom);
    mmu->cart.rom_bank = 1;
    mmu->cart.ram_bank = 0;

    /* Taille RAM cartouche d'après l'octet 0x149 (approximation classique) */
    uint32_t ram_sizes[] = {0, 2*1024, 8*1024, 32*1024, 128*1024, 64*1024};
    uint8_t code = rom[0x149];
    mmu->cart.ram_size = (code < 6) ? ram_sizes[code] : 0;
    /* Note: l'allocation réelle de cart.ram doit être faite par l'appelant
       (gb_init) car malloc n'est pas utilisé ici pour rester simple/portable. */

    /* Joypad: aucune touche pressée par défaut = tous les bits à 1 */
    mmu->joypad_buttons = 0x0F;
    mmu->joypad_dpad = 0x0F;
    mmu->io[IO_JOYP] = 0xFF;
}

static uint8_t rom_read(mmu_t *m, uint16_t addr)
{
    cart_t *c = &m->cart;
    if (addr < 0x4000) {
        return c->rom[addr];
    }
    /* banque switchable 0x4000-0x7FFF */
    uint32_t bank = c->rom_bank;
    if (bank == 0) bank = 1;
    uint32_t offset = (uint32_t)bank * 0x4000u + (addr - 0x4000);
    if (offset >= c->rom_size) offset %= c->rom_size;
    return c->rom[offset];
}

static void mbc_write(mmu_t *m, uint16_t addr, uint8_t val)
{
    cart_t *c = &m->cart;
    switch (c->mbc) {
    case MBC_NONE:
        break; /* ROM only: écritures ignorées */

    case MBC_1:
        if (addr < 0x2000) {
            c->ram_enabled = ((val & 0x0F) == 0x0A);
        } else if (addr < 0x4000) {
            uint8_t bank = val & 0x1F;
            if (bank == 0) bank = 1;
            c->rom_bank = (c->rom_bank & 0x60) | bank;
        } else if (addr < 0x6000) {
            if (c->bank_mode == 0)
                c->rom_bank = (c->rom_bank & 0x1F) | ((val & 0x03) << 5);
            else
                c->ram_bank = val & 0x03;
        } else {
            c->bank_mode = val & 0x01;
        }
        break;

    case MBC_2:
        if (addr < 0x2000) {
            if ((addr & 0x0100) == 0) c->ram_enabled = ((val & 0x0F) == 0x0A);
        } else if (addr < 0x4000) {
            if (addr & 0x0100) {
                uint8_t bank = val & 0x0F;
                c->rom_bank = bank ? bank : 1;
            }
        }
        break;

    case MBC_3:
        if (addr < 0x2000) {
            c->ram_enabled = ((val & 0x0F) == 0x0A);
        } else if (addr < 0x4000) {
            uint8_t bank = val & 0x7F;
            c->rom_bank = bank ? bank : 1;
        } else if (addr < 0x6000) {
            c->ram_bank = val; /* 0x00-0x03 = RAM bank, 0x08-0x0C = RTC (non émulé) */
        }
        /* écriture 0x6000-0x7FFF = latch RTC, ignoré ici */
        break;

    case MBC_5:
        if (addr < 0x2000) {
            c->ram_enabled = ((val & 0x0F) == 0x0A);
        } else if (addr < 0x3000) {
            c->rom_bank = (c->rom_bank & 0x100) | val;
        } else if (addr < 0x4000) {
            c->rom_bank = (c->rom_bank & 0xFF) | ((val & 1) << 8);
        } else if (addr < 0x6000) {
            c->ram_bank = val & 0x0F;
        }
        break;

    default:
        break;
    }
}

static uint8_t joypad_read(mmu_t *m)
{
    uint8_t joyp = m->io[IO_JOYP];
    uint8_t result = joyp | 0x0F;
    if (!(joyp & 0x10)) result &= (0xF0 | m->joypad_dpad);
    if (!(joyp & 0x20)) result &= (0xF0 | m->joypad_buttons);
    return result;
}

uint8_t mmu_read(gb_t *gb, uint16_t addr)
{
    mmu_t *m = &gb->mmu;

    if (addr < 0x8000) return rom_read(m, addr);
    if (addr < 0xA000) return m->vram[addr - 0x8000];
    if (addr < 0xC000) {
        cart_t *c = &m->cart;
        if (!c->ram || !c->ram_enabled) return 0xFF;
        uint32_t off = (uint32_t)c->ram_bank * 0x2000u + (addr - 0xA000);
        if (c->ram_size == 0) return 0xFF;
        return c->ram[off % c->ram_size];
    }
    if (addr < 0xE000) return m->wram[addr - 0xC000];
    if (addr < 0xFE00) return m->wram[addr - 0xE000]; /* echo RAM */
    if (addr < 0xFEA0) return m->oam[addr - 0xFE00];
    if (addr < 0xFF00) return 0xFF; /* zone non utilisable */
    if (addr < 0xFF80) {
        if (addr - 0xFF00 == IO_JOYP) return joypad_read(m);
        return m->io[addr - 0xFF00];
    }
    if (addr < 0xFFFF) return m->hram[addr - 0xFF80];
    return m->ie_reg;
}

static void dma_transfer(gb_t *gb, uint8_t val)
{
    uint16_t src = (uint16_t)val << 8;
    for (int i = 0; i < 0xA0; i++)
        gb->mmu.oam[i] = mmu_read(gb, src + i);
}

void mmu_write(gb_t *gb, uint16_t addr, uint8_t val)
{
    mmu_t *m = &gb->mmu;

    if (addr < 0x8000) { mbc_write(m, addr, val); return; }
    if (addr < 0xA000) { m->vram[addr - 0x8000] = val; return; }
    if (addr < 0xC000) {
        cart_t *c = &m->cart;
        if (c->ram && c->ram_enabled && c->ram_size) {
            uint32_t off = (uint32_t)c->ram_bank * 0x2000u + (addr - 0xA000);
            c->ram[off % c->ram_size] = val;
        }
        return;
    }
    if (addr < 0xE000) { m->wram[addr - 0xC000] = val; return; }
    if (addr < 0xFE00) { m->wram[addr - 0xE000] = val; return; }
    if (addr < 0xFEA0) { m->oam[addr - 0xFE00] = val; return; }
    if (addr < 0xFF00) return;

    if (addr < 0xFF80) {
        int reg = addr - 0xFF00;
        switch (reg) {
        case IO_SC:
            if (val & 0x80) {
                if (gb_serial_hook) gb_serial_hook((char)m->io[IO_SB]);
                gb_request_interrupt(gb, INT_SERIAL);
            }
            m->io[IO_SC] = val & 0x7F;
            return;
        case IO_DIV:  m->io[IO_DIV] = 0; gb->timer.div_counter = 0; return;
        case IO_DMA:  dma_transfer(gb, val); m->io[IO_DMA] = val; return;
        case IO_LY:   return; /* lecture seule */
        default: m->io[reg] = val; return;
        }
    }
    if (addr < 0xFFFF) { m->hram[addr - 0xFF80] = val; return; }
    m->ie_reg = val;
}

void (*gb_serial_hook)(char c) = NULL;

void gb_request_interrupt(gb_t *gb, int bit)
{
    gb->mmu.io[IO_IF] |= (1 << bit);
}
