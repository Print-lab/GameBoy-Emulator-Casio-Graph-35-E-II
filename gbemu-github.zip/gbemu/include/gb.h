/* gb.h - Structures et déclarations communes de l'émulateur
 *
 * Portage pour Casio Graph 35+E II (SH-4A, gint/fxSDK), écran 128x64 mono.
 */
#ifndef GBEMU_GB_H_INCLUDED
#define GBEMU_GB_H_INCLUDED

#include <stdint.h>
#include <stdbool.h>

/* ---- Résolution native Game Boy ---- */
#define GB_W 160
#define GB_H 144

/* ---- Registres CPU (SM83, proche LR35902/Z80) ---- */
typedef struct {
    /* Les paires sont stockees comme de simples uint16_t. On extrait les
       octets haut/bas par arithmetique (decalage/masque), jamais par la
       disposition memoire d'une union : cette derniere depend de
       l'endianness de la machine et casserait tout sur un processeur
       big-endian comme le SH-4 de la calculatrice (cible sh3eb-elf, "eb" =
       big-endian), alors qu'elle marche "par hasard" sur un PC x86
       (little-endian) -- ce qui rendait le bug invisible lors des tests. */
    uint16_t af, bc, de, hl;
    uint16_t sp;
    uint16_t pc;

    bool ime;          /* Interrupt Master Enable */
    bool ime_pending;  /* EI retarde l'activation d'1 instruction */
    bool halted;
    bool stopped;

    uint64_t cycles;   /* cycles machine (T-states) écoulés */
} cpu_t;

/* Accesseurs des 8 registres 8 bits, independants de l'endianness. */
static inline uint8_t r_a(const cpu_t *c) { return (uint8_t)(c->af >> 8); }
static inline uint8_t r_f(const cpu_t *c) { return (uint8_t)(c->af & 0xFF); }
static inline uint8_t r_b(const cpu_t *c) { return (uint8_t)(c->bc >> 8); }
static inline uint8_t r_c(const cpu_t *c) { return (uint8_t)(c->bc & 0xFF); }
static inline uint8_t r_d(const cpu_t *c) { return (uint8_t)(c->de >> 8); }
static inline uint8_t r_e(const cpu_t *c) { return (uint8_t)(c->de & 0xFF); }
static inline uint8_t r_h(const cpu_t *c) { return (uint8_t)(c->hl >> 8); }
static inline uint8_t r_l(const cpu_t *c) { return (uint8_t)(c->hl & 0xFF); }

static inline void set_a(cpu_t *c, uint8_t v) { c->af = (uint16_t)((c->af & 0x00FF) | ((uint16_t)v << 8)); }
static inline void set_f(cpu_t *c, uint8_t v) { c->af = (uint16_t)((c->af & 0xFF00) | (v & 0xF0)); }
static inline void set_b(cpu_t *c, uint8_t v) { c->bc = (uint16_t)((c->bc & 0x00FF) | ((uint16_t)v << 8)); }
static inline void set_c(cpu_t *c, uint8_t v) { c->bc = (uint16_t)((c->bc & 0xFF00) | v); }
static inline void set_d(cpu_t *c, uint8_t v) { c->de = (uint16_t)((c->de & 0x00FF) | ((uint16_t)v << 8)); }
static inline void set_e(cpu_t *c, uint8_t v) { c->de = (uint16_t)((c->de & 0xFF00) | v); }
static inline void set_h(cpu_t *c, uint8_t v) { c->hl = (uint16_t)((c->hl & 0x00FF) | ((uint16_t)v << 8)); }
static inline void set_l(cpu_t *c, uint8_t v) { c->hl = (uint16_t)((c->hl & 0xFF00) | v); }

/* Flags dans le registre F */
#define FLAG_Z 0x80
#define FLAG_N 0x40
#define FLAG_H 0x20
#define FLAG_C 0x10

/* ---- Cartouche / MBC ---- */
typedef enum { MBC_NONE = 0, MBC_1, MBC_2, MBC_3, MBC_5, MBC_UNSUPPORTED } mbc_type_t;

typedef struct {
    const uint8_t *rom;      /* pointeur vers la ROM embarquée (flash) */
    uint32_t rom_size;
    uint8_t *ram;             /* RAM cartouche (SRAM), allouée si présente */
    uint32_t ram_size;

    mbc_type_t mbc;
    bool ram_enabled;
    bool battery;
    uint8_t rom_bank;         /* banque ROM sélectionnée (0x4000-0x7FFF) */
    uint8_t ram_bank;
    uint8_t bank_mode;        /* MBC1: 0 = ROM banking mode, 1 = RAM banking mode */
} cart_t;

/* ---- Mémoire ---- */
typedef struct {
    cart_t cart;
    uint8_t vram[0x2000];     /* 0x8000-0x9FFF */
    uint8_t wram[0x2000];     /* 0xC000-0xDFFF (pas de switch CGB ici) */
    uint8_t oam[0xA0];        /* 0xFE00-0xFE9F */
    uint8_t io[0x80];         /* 0xFF00-0xFF7F */
    uint8_t hram[0x7F];       /* 0xFF80-0xFFFE */
    uint8_t ie_reg;           /* 0xFFFF */

    uint8_t joypad_buttons;   /* bit=0 -> pressé, format GB (bits 0-3) */
    uint8_t joypad_dpad;
} mmu_t;

/* ---- PPU ---- */
typedef struct {
    /* Framebuffer compresse a 2 bits/pixel (4 teintes) : 144 x 40 = 5760
       octets au lieu de 144 x 160 = 23040 avec 1 octet/pixel. Sur un
       fx-9860G, la region RAM statique est trop petite pour se permettre
       le format non compresse. */
    uint8_t framebuffer[GB_H][(GB_W + 3) / 4];
    int mode;         /* 0=HBlank,1=VBlank,2=OAM,3=Transfer */
    int mode_clock;
    int line;         /* LY courante */
    bool frame_ready;
} ppu_t;

static inline uint8_t ppu_get_pixel(const ppu_t *p, int x, int y) {
    uint8_t byte = p->framebuffer[y][x >> 2];
    return (byte >> ((x & 3) * 2)) & 0x03;
}
static inline void ppu_set_pixel(ppu_t *p, int x, int y, uint8_t shade) {
    uint8_t *b = &p->framebuffer[y][x >> 2];
    int shift = (x & 3) * 2;
    *b = (uint8_t)((*b & ~(0x03 << shift)) | ((shade & 0x03) << shift));
}

/* ---- Timer ---- */
typedef struct {
    uint16_t div_counter;  /* compteur interne 16 bits, DIV = high byte */
    int tima_counter;
} gbtimer_t;

/* ---- État global de la machine ---- */
typedef struct {
    cpu_t cpu;
    mmu_t mmu;
    ppu_t ppu;
    gbtimer_t timer;
} gb_t;

/* API */
void gb_init(gb_t *gb, const uint8_t *rom, uint32_t rom_size);
void gb_run_frame(gb_t *gb);           /* exécute ~70224 cycles (1 frame GB) */
void gb_request_interrupt(gb_t *gb, int bit);

/* Point d'accroche optionnel pour capturer la sortie du port serie (protocole
   utilise par les ROMs de test de Blargg pour rapporter leurs resultats en
   texte). NULL par defaut : ne fait rien (comportement normal sur la
   calculatrice, aucun cout). */
extern void (*gb_serial_hook)(char c);

/* MMU */
uint8_t mmu_read(gb_t *gb, uint16_t addr);
void mmu_write(gb_t *gb, uint16_t addr, uint8_t val);
void mmu_init(mmu_t *mmu, const uint8_t *rom, uint32_t rom_size);

/* CPU */
void cpu_init(cpu_t *cpu);
int  cpu_step(gb_t *gb); /* exécute une instruction, renvoie le nb de cycles machine */

/* PPU */
void ppu_init(ppu_t *ppu);
void ppu_step(gb_t *gb, int cycles);

/* Timer */
void timer_init(gbtimer_t *t);
void timer_step(gb_t *gb, int cycles);

/* Interrupts bits */
#define INT_VBLANK 0
#define INT_LCDSTAT 1
#define INT_TIMER  2
#define INT_SERIAL 3
#define INT_JOYPAD 4

/* Registres IO utiles (offsets dans mmu.io, base 0xFF00) */
#define IO_JOYP  0x00
#define IO_SB    0x01
#define IO_SC    0x02
#define IO_DIV   0x04
#define IO_TIMA  0x05
#define IO_TMA   0x06
#define IO_TAC   0x07
#define IO_IF    0x0F
#define IO_LCDC  0x40
#define IO_STAT  0x41
#define IO_SCY   0x42
#define IO_SCX   0x43
#define IO_LY    0x44
#define IO_LYC   0x45
#define IO_DMA   0x46
#define IO_BGP   0x47
#define IO_OBP0  0x48
#define IO_OBP1  0x49
#define IO_WY    0x4A
#define IO_WX    0x4B

#endif
