#!/usr/bin/env python3
"""rom2c.py - Convertit une ROM Game Boy (.gb) en tableau C embarquable.

Usage :
    python3 tools/rom2c.py ma_rom.gb src/rom.c include/rom.h

La ROM est placée en section .rodata : elle finira dans la flash de l'add-in,
pas en RAM (indispensable, la calculatrice n'a pas assez de RAM pour charger
une ROM entière).

N'utilisez que des ROMs que vous avez dumpées vous-même depuis une cartouche
que vous possedez.
"""
import sys
import os

CART_TYPES = {
    0x00: "ROM ONLY", 0x01: "MBC1", 0x02: "MBC1+RAM", 0x03: "MBC1+RAM+BATTERY",
    0x05: "MBC2", 0x06: "MBC2+BATTERY",
    0x0F: "MBC3+TIMER+BATTERY", 0x10: "MBC3+TIMER+RAM+BATTERY",
    0x11: "MBC3", 0x12: "MBC3+RAM", 0x13: "MBC3+RAM+BATTERY",
    0x19: "MBC5", 0x1A: "MBC5+RAM", 0x1B: "MBC5+RAM+BATTERY",
}

SUPPORTED = {0x00, 0x01, 0x02, 0x03, 0x05, 0x06, 0x0F, 0x10, 0x11, 0x12, 0x13,
             0x19, 0x1A, 0x1B}


def main():
    if len(sys.argv) != 4:
        print(__doc__)
        return 1

    rom_path, c_path, h_path = sys.argv[1], sys.argv[2], sys.argv[3]

    with open(rom_path, "rb") as f:
        data = f.read()

    if len(data) < 0x150:
        print("Erreur : fichier trop petit pour etre une ROM Game Boy.")
        return 1

    title = data[0x134:0x143].rstrip(b"\x00").decode("ascii", "replace")
    cart_type = data[0x147]
    rom_size_code = data[0x148]
    ram_size_code = data[0x149]
    cgb_flag = data[0x143]

    print(f"Titre        : {title}")
    print(f"Type         : 0x{cart_type:02X} ({CART_TYPES.get(cart_type, 'inconnu')})")
    print(f"Taille ROM   : {len(data)} octets ({len(data)//1024} Ko), code 0x{rom_size_code:02X}")
    print(f"Taille RAM   : code 0x{ram_size_code:02X}")

    if cart_type not in SUPPORTED:
        print("ATTENTION : ce type de cartouche n'est pas gere par l'emulateur.")
    if cgb_flag in (0x80, 0xC0):
        print("ATTENTION : ROM Game Boy Color. Seul le mode DMG est emule, "
              "l'affichage sera probablement incorrect.")
    if len(data) > 1024 * 1024:
        print("ATTENTION : ROM > 1 Mo. La flash de la G35+E II est de 8 Mio mais "
              "la taille max d'un add-in est bien plus faible ; prevoyez des soucis.")

    os.makedirs(os.path.dirname(c_path) or ".", exist_ok=True)
    os.makedirs(os.path.dirname(h_path) or ".", exist_ok=True)

    with open(c_path, "w") as f:
        f.write("/* Genere automatiquement par tools/rom2c.py - ne pas editer */\n")
        f.write('#include "rom.h"\n\n')
        f.write("const unsigned int gb_rom_size = %d;\n\n" % len(data))
        f.write("__attribute__((aligned(4)))\n")
        f.write("const unsigned char gb_rom[%d] = {\n" % len(data))
        for i in range(0, len(data), 16):
            chunk = data[i:i + 16]
            f.write("    " + ",".join("0x%02X" % b for b in chunk) + ",\n")
        f.write("};\n")

    with open(h_path, "w") as f:
        f.write("/* Genere automatiquement par tools/rom2c.py - ne pas editer */\n")
        f.write("#ifndef ROM_H\n#define ROM_H\n\n")
        f.write("extern const unsigned char gb_rom[];\n")
        f.write("extern const unsigned int gb_rom_size;\n\n")
        f.write("#endif\n")

    print(f"\nEcrit : {c_path} et {h_path}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
