#!/bin/sh
# Telecharge les ROMs de test de Blargg (outils de test libres, pas des jeux
# commerciaux) et execute les suites cpu_instrs + instr_timing sur le coeur
# compile pour PC. Necessite git et gcc.
set -e
cd "$(dirname "$0")/.."

if [ ! -d tools/gb-test-roms ]; then
    git clone --depth 1 https://github.com/retrio/gb-test-roms.git tools/gb-test-roms
fi

gcc -std=c11 -O2 -Iinclude src/cpu.c src/mmu.c src/ppu.c src/timer.c src/gb.c \
    tools/blargg_test.c -o blargg_test

fail=0
for f in tools/gb-test-roms/cpu_instrs/individual/*.gb \
         tools/gb-test-roms/instr_timing/instr_timing.gb; do
    # 40 s emulees : certains tests (ex. 11) sont longs.
    if ./blargg_test "$f" 40 | grep -q "^\[OK\]"; then
        echo "OK     $(basename "$f")"
    else
        echo "ECHEC  $(basename "$f")"; fail=1
    fi
done
exit $fail
