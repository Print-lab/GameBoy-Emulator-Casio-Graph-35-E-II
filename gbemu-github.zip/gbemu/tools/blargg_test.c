/* blargg_test.c - Charge une ROM de test Blargg, capture sa sortie serie,
 * l'affiche. Usage : blargg_test chemin/vers/test.gb [max_secondes_emulees]
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "gb.h"

static char outbuf[8192];
static int outlen = 0;

static void capture(char c)
{
    if (outlen < (int)sizeof(outbuf) - 1) outbuf[outlen++] = c;
}

int main(int argc, char **argv)
{
    if (argc < 2) { fprintf(stderr, "usage: %s rom.gb [secondes]\n", argv[0]); return 1; }

    FILE *f = fopen(argv[1], "rb");
    if (!f) { perror("fopen"); return 1; }
    static uint8_t rom[1024 * 1024];
    size_t n = fread(rom, 1, sizeof(rom), f);
    fclose(f);

    int seconds = argc > 2 ? atoi(argv[2]) : 15;

    gb_t g;
    gb_init(&g, rom, (uint32_t)n);
    gb_serial_hook = capture;

    int frames = seconds * 60; /* ~60 fps */
    for (int i = 0; i < frames; i++) {
        gb_run_frame(&g);
        if (outlen > 0 && (strstr(outbuf, "Passed") || strstr(outbuf, "Failed")))
            break;
    }

    outbuf[outlen] = 0;
    printf("=== %s ===\n%s\n", argv[1], outbuf);
    if (strstr(outbuf, "Passed")) { printf("[OK]\n"); return 0; }
    printf("[PAS DE 'Passed' -> ECHEC OU TIMEOUT]\n");
    return 1;
}
