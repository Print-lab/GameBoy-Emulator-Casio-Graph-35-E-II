/* test_host.c - Banc de test PC du coeur d'emulation.
 * Assemble a la main une petite ROM Game Boy (aucun contenu sous droits),
 * l'execute, et affiche le framebuffer en ASCII. Sert a valider CPU+PPU+MMU
 * avant de compiler pour la calculatrice.
 *
 * Build : gcc -std=c11 -Iinclude src/cpu.c src/mmu.c src/ppu.c src/timer.c \
 *              src/gb.c tools/test_host.c -o /tmp/test_host
 */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "gb.h"

static uint8_t rom[0x8000];
static int pos;

static void emit(uint8_t b) { rom[pos++] = b; }
static void emit_ld_a(uint8_t v)      { emit(0x3E); emit(v); }
static void emit_ld_hl(uint16_t v)    { emit(0x21); emit(v & 0xFF); emit(v >> 8); }
static void emit_ld_nn_a(uint16_t nn) { emit(0xEA); emit(nn & 0xFF); emit(nn >> 8); }
static void emit_ldi_hl_a(void)       { emit(0x22); }

static void build_rom(void)
{
    memset(rom, 0, sizeof(rom));
    /* Entry point a 0x100 : saute au code principal en 0x150 */
    pos = 0x100;
    emit(0x00);              /* NOP */
    emit(0xC3); emit(0x50); emit(0x01);  /* JP 0x0150 */

    /* En-tete : titre + type cartouche ROM ONLY */
    memcpy(&rom[0x134], "TESTROM", 7);
    rom[0x147] = 0x00; /* ROM ONLY */
    rom[0x148] = 0x00; /* 32 Ko */
    rom[0x149] = 0x00; /* pas de RAM */

    pos = 0x150;

    /* 1) Ecrire deux tuiles en VRAM a 0x8000.
     *    Tuile 0 : vide (deja a zero). Tuile 1 : damier en couleur 3. */
    emit_ld_hl(0x8010);          /* tuile 1 */
    for (int i = 0; i < 8; i++) {
        /* chaque ligne : 2 octets (plan bas, plan haut) = 0xFF,0xFF -> couleur 3 */
        emit_ld_a(i % 2 ? 0xAA : 0x55); emit_ldi_hl_a();
        emit_ld_a(i % 2 ? 0xAA : 0x55); emit_ldi_hl_a();
    }

    /* 2) Remplir la tilemap 0x9800 avec la tuile 1 sur 32x32 entrees.
     *    Boucle : BC = 1024, HL = 0x9800, A = 1 */
    emit_ld_hl(0x9800);
    emit(0x01); emit(0x00); emit(0x04);  /* LD BC, 0x0400 */
    emit_ld_a(0x01);
    int loop = pos;
    emit_ldi_hl_a();                      /* LD (HL+), A */
    emit(0x0B);                           /* DEC BC */
    emit(0x78);                           /* LD A,B   (ecrase A !) */
    emit(0xB1);                           /* OR C     -> positionne Z */
    emit(0x3E); emit(0x01);               /* LD A,1   (n'affecte pas les flags) */
    emit(0x20);                           /* JR NZ, d */
    /* Le deplacement est relatif a l'adresse SUIVANT l'operande, donc
       pos+1 une fois l'operande ecrit. */
    emit((uint8_t)(int8_t)(loop - (pos + 1)));
    emit_ld_a(0x01);                      /* restaurer A=1 (ecrase par LD A,B) */

    /* 3) Configurer la palette et allumer le LCD */
    emit_ld_a(0xE4); emit_ld_nn_a(0xFF47);  /* BGP = 11 10 01 00 */
    emit_ld_a(0x00); emit_ld_nn_a(0xFF42);  /* SCY = 0 */
    emit_ld_a(0x00); emit_ld_nn_a(0xFF43);  /* SCX = 0 */
    emit_ld_a(0x91); emit_ld_nn_a(0xFF40);  /* LCDC : LCD on, BG on, tiles 0x8000 */

    /* 4) Boucle infinie : incremente SCX pour verifier le scrolling */
    int mainloop = pos;
    emit(0xFA); emit(0x43); emit(0xFF);   /* LD A,(0xFF43) */
    emit(0x3C);                           /* INC A */
    emit_ld_nn_a(0xFF43);                 /* LD (0xFF43),A */
    emit(0xC3); emit(mainloop & 0xFF); emit(mainloop >> 8); /* JP mainloop */
}

/* --- Verification des flags sur quelques instructions cles --- */
static int checks_failed = 0;

static void check(const char *name, int got, int expected)
{
    if (got != expected) {
        printf("  ECHEC %-24s obtenu=0x%02X attendu=0x%02X\n", name, got, expected);
        checks_failed++;
    } else {
        printf("  ok    %-24s 0x%02X\n", name, got);
    }
}

static void test_cpu_basics(void)
{
    gb_t g;
    printf("Tests unitaires CPU :\n");

    /* ADD A,B avec retenue demi-octet et retenue */
    gb_init(&g, rom, sizeof(rom));
    set_a(&g.cpu, 0x3A); set_b(&g.cpu, 0xC6); set_f(&g.cpu, 0);
    g.cpu.pc = 0xC000;
    mmu_write(&g, 0xC000, 0x80); /* ADD A,B */
    cpu_step(&g);
    check("ADD A,B resultat", r_a(&g.cpu), 0x00);
    check("ADD A,B flags", r_f(&g.cpu), FLAG_Z | FLAG_H | FLAG_C);

    /* SUB provoquant un emprunt */
    gb_init(&g, rom, sizeof(rom));
    set_a(&g.cpu, 0x10); set_b(&g.cpu, 0x01); set_f(&g.cpu, 0);
    g.cpu.pc = 0xC000;
    mmu_write(&g, 0xC000, 0x90); /* SUB B */
    cpu_step(&g);
    check("SUB B resultat", r_a(&g.cpu), 0x0F);
    check("SUB B flags", r_f(&g.cpu), FLAG_N | FLAG_H);

    /* SWAP via prefixe CB */
    gb_init(&g, rom, sizeof(rom));
    set_a(&g.cpu, 0xF0); set_f(&g.cpu, 0);
    g.cpu.pc = 0xC000;
    mmu_write(&g, 0xC000, 0xCB); mmu_write(&g, 0xC001, 0x37); /* SWAP A */
    cpu_step(&g);
    check("SWAP A", r_a(&g.cpu), 0x0F);

    /* PUSH/POP BC conserve la valeur */
    gb_init(&g, rom, sizeof(rom));
    g.cpu.bc = 0x1234; g.cpu.sp = 0xDFF0; g.cpu.pc = 0xC000;
    mmu_write(&g, 0xC000, 0xC5); /* PUSH BC */
    mmu_write(&g, 0xC001, 0xD1); /* POP DE */
    cpu_step(&g); cpu_step(&g);
    check("PUSH BC / POP DE hi", r_d(&g.cpu), 0x12);
    check("PUSH BC / POP DE lo", r_e(&g.cpu), 0x34);

    /* CALL puis RET revient a la bonne adresse */
    gb_init(&g, rom, sizeof(rom));
    g.cpu.sp = 0xDFF0; g.cpu.pc = 0xC000;
    mmu_write(&g, 0xC000, 0xCD); mmu_write(&g, 0xC001, 0x10); mmu_write(&g, 0xC002, 0xC0);
    mmu_write(&g, 0xC010, 0xC9); /* RET */
    cpu_step(&g);
    check("CALL destination", g.cpu.pc, 0xC010);
    cpu_step(&g);
    check("RET retour", g.cpu.pc, 0xC003);

    /* Rotation RL A avec report de la retenue */
    gb_init(&g, rom, sizeof(rom));
    set_a(&g.cpu, 0x80); set_f(&g.cpu, 0); g.cpu.pc = 0xC000;
    mmu_write(&g, 0xC000, 0x17); /* RLA */
    cpu_step(&g);
    check("RLA resultat", r_a(&g.cpu), 0x00);
    check("RLA carry", (r_f(&g.cpu) & FLAG_C) != 0, 1);
    check("RLA Z force a 0", (r_f(&g.cpu) & FLAG_Z) != 0, 0);
}

static void dump_frame(gb_t *g)
{
    static const char shades[4] = {' ', '.', '+', '#'};
    /* On echantillonne pour tenir dans un terminal : 1 colonne sur 2, 1 ligne sur 4 */
    for (int y = 0; y < GB_H; y += 4) {
        for (int x = 0; x < GB_W; x += 2)
            putchar(shades[g->ppu.framebuffer[y][x] & 3]);
        putchar('\n');
    }
}

int main(void)
{
    build_rom();
    test_cpu_basics();

    printf("\nExecution de la mini-ROM...\n");
    gb_t g;
    gb_init(&g, rom, sizeof(rom));

    for (int frame = 0; frame < 20; frame++)
        gb_run_frame(&g);

    /* Statistiques : combien de pixels non blancs ? */
    int nonwhite = 0;
    for (int y = 0; y < GB_H; y++)
        for (int x = 0; x < GB_W; x++)
            if (g.ppu.framebuffer[y][x] != 0) nonwhite++;

    printf("PC final      : 0x%04X\n", g.cpu.pc);
    printf("SCX apres 20f : %d\n", g.mmu.io[IO_SCX]);
    printf("LCDC          : 0x%02X\n", g.mmu.io[IO_LCDC]);
    printf("Pixels non blancs : %d / %d\n\n", nonwhite, GB_W * GB_H);

    dump_frame(&g);

    if (checks_failed) {
        printf("\n%d verification(s) en echec.\n", checks_failed);
        return 1;
    }
    if (nonwhite == 0) {
        printf("\nECHEC : le PPU n'a rien dessine.\n");
        return 1;
    }
    printf("\nTous les tests passent.\n");
    return 0;
}
